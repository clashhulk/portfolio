[![Netlify Status](https://api.netlify.com/api/v1/badges/6677c046-9e24-4942-97c6-0416253dfacb/deploy-status)](https://app.netlify.com/sites/akshata/deploys)

# Akshata Bhimnale Portfolio
